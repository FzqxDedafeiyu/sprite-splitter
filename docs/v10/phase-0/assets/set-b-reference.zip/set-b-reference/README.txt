Sprite Splitter Phase-0 test image set
======================================

These are approximate crops from one generated concept sheet.
They are useful as visual smoke-test inputs, but are NOT authoritative
ground-truth assets.

Important limitations:
- The generated sheet has a dark gradient background, not true transparency.
  Do not use it to claim A-003 real-alpha validation.
- A-002 contains nearby objects, but exact contact/diagonal-contact cases
  are limited; add a purpose-built contact test if testing 4/8-neighbour rules.
- A-005 contains small particles, but the expected keep/filter policy must
  be specified by the test operator.
- A-007 shows four poses in one crop, not four separately named frame files.
- A-008 is a compact scene illustration, not a rigorously layered parallax
  source with separate depth planes.

Suggested mapping:
A-001 single mushroom: simple single-object crop
A-002 close objects: gem/coin/leaf/potion cluster
A-003 chest crop: visual import/export smoke test only; NOT transparency proof
A-004 glowing wisp: soft glow / edge inspection
A-005 particles: small isolated-pixel detection
A-006 forest parts: manual add/split selection practice
A-007 slime sequence: animation-frame ordering concept
A-008 scene: scene-layout / composition concept

For strict acceptance testing, create separate source assets with documented
expected bounding boxes, alpha-channel expectations, and frame/layer metadata.
